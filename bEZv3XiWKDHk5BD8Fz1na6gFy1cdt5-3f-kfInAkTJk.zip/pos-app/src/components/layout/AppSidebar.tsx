"use client";

import {
  Home,
  Target,
  LayoutList,
  CheckCircle,
  Repeat,
  FolderKanban,
  Settings,
  BookOpen,
  LineChart,
  SearchCheck,
} from "lucide-react";
import { usePathname } from "next/navigation";
import Link from "next/link";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

// Grouping navigation items for better UX
const navGroups = [
  {
    label: "Command Center",
    items: [
      { title: "Dashboard", url: "/", icon: Home },
    ],
  },
  {
    label: "Strategy (Planning)",
    items: [
      { title: "Identity", url: "/identity", icon: Target },
      { title: "Constitution", url: "/constitution", icon: BookOpen },
      { title: "Vision", url: "/vision", icon: Target },
      { title: "Life Areas", url: "/life-areas", icon: LayoutList },
      { title: "Goals", url: "/goals", icon: Target },
    ],
  },
  {
    label: "Execution (Doing)",
    items: [
      { title: "Projects", url: "/projects", icon: FolderKanban },
      { title: "Tasks", url: "/tasks", icon: CheckCircle },
      { title: "Habits", url: "/habits", icon: Repeat },
    ],
  },
  {
    label: "Tracking (Reviewing)",
    items: [
      { title: "Journal", url: "/journal", icon: BookOpen },
      { title: "Reviews", url: "/reviews", icon: SearchCheck },
      { title: "Analytics", url: "/analytics", icon: LineChart }, // Placeholder
    ],
  },
];

export function AppSidebar() {
  const pathname = usePathname();

  return (
    <Sidebar variant="sidebar" collapsible="icon">
      <SidebarHeader className="p-4 border-b">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground shrink-0">
            <span className="font-bold">OS</span>
          </div>
          <span className="font-bold text-lg tracking-tight truncate group-data-[collapsible=icon]:hidden">
            Personal OS
          </span>
        </div>
      </SidebarHeader>

      <SidebarContent>
        {navGroups.map((group, index) => (
          <SidebarGroup key={index}>
            <SidebarGroupLabel>{group.label}</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {group.items.map((item) => {
                  const isActive = pathname === item.url || (pathname.startsWith(item.url) && item.url !== "/");
                  
                  return (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton isActive={isActive} tooltip={item.title}>
                        <Link href={item.url} className="flex items-center gap-2 w-full h-full">
                          <item.icon className="h-4 w-4 shrink-0" />
                          <span className="truncate">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>

      <SidebarFooter className="p-4 border-t group-data-[collapsible=icon]:p-2">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton tooltip="Settings">
              <Link href="/settings" className="flex items-center gap-2 w-full h-full">
                <Settings className="h-4 w-4 shrink-0" />
                <span className="truncate">Settings</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <div className="flex items-center gap-3 px-2 py-2 w-full mt-2 overflow-hidden bg-muted/50 rounded-lg">
              <Avatar className="h-8 w-8 rounded-md shrink-0 border border-background">
                <AvatarFallback className="rounded-md bg-primary/10 text-primary font-semibold">ME</AvatarFallback>
              </Avatar>
              <div className="flex flex-col flex-1 group-data-[collapsible=icon]:hidden truncate">
                <span className="text-sm font-medium leading-none truncate">Test User</span>
                <span className="text-[10px] text-muted-foreground mt-1 truncate">Free Plan</span>
              </div>
            </div>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}