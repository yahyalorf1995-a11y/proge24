import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  serverExternalPackages: ["@prisma/client", "pg"],
  typescript: {
    ignoreBuildErrors: false,
  },

  // Dev environments (Codespaces, Gitpod, ngrok, etc.) serve the app through
  // a proxy domain that differs from the Host the dev server itself sees.
  // Next.js's CSRF check on Server Actions compares the request's Origin
  // against an allowlist — in Codespaces the browser's Origin is actually
  // "localhost:3000" (not the public *.app.github.dev URL), so that must be
  // in the list too, alongside the public proxy domains.
  allowedDevOrigins: [
    "localhost:3000",
    "*.app.github.dev",
    "*.github.dev",
    "*.githubpreview.dev",
  ],
  experimental: {
    serverActions: {
      allowedOrigins: [
        "localhost:3000",
        "*.app.github.dev",
        "*.github.dev",
        "*.githubpreview.dev",
      ],
      allowedForwardedHosts: [
        "localhost:3000",
        "*.app.github.dev",
        "*.github.dev",
        "*.githubpreview.dev",
      ],
    },
  },
};

export default nextConfig;
