# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workflows.spec.ts >> Interaction Audit >> Sidebar and Navigation
- Location: tests/workflows.spec.ts:5:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator:  locator('a[href="/identity"]')
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('a[href="/identity"]')
    14 × locator resolved to <a href="/identity" class="flex items-center gap-2.5 w-full h-full">…</a>
       - unexpected value "hidden"

```

```yaml
- main:
  - button "Toggle Sidebar"
  - text: Command Center Wednesday, July 15
  - heading "Command Center" [level=1]
  - paragraph: Your personal operating system overview. Stay aligned and execute.
  - link "Log Journal":
    - /url: /journal
    - button "Log Journal"
  - link "New Task":
    - /url: /tasks
    - button "New Task"
  - text: Action Required Your highest priority tasks and today's focus. Complete first 5k run 16-Week Training Program
  - button "Done"
  - text: Gather links for recent projects Update Portfolio & Resume
  - button "Done"
  - text: Active Projects Moving the needle forward. 16-Week Training Program Health & Fitness Progress 15% Daily Habits
  - button "Undo habit"
  - text: Morning Stretch 12
  - button "Complete habit"
  - text: Read 10 Pages 4
  - button "Complete habit"
  - text: QA Habit 0 OS Insights
  - paragraph: Alignment Check
  - paragraph: You have 1 active project(s). Keep pushing.
  - paragraph: Execution Warning
  - paragraph: Your task list is manageable (1 pending). Great job staying on top of it.
  - heading "Trajectory" [level=4]
  - text: Run a Marathon 35% Latest Review WEEKLY 8/10
  - paragraph: Systems over goals. When the habit is tracked, I am 90% more likely to do it.
  - text: Activity Log AWESOME
  - paragraph: Today was highly productive. I managed to finish the core modules of the project. I feel aligned with my goals.
- alert
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | test.describe('Interaction Audit', () => {
  4   | 
  5   |   test('Sidebar and Navigation', async ({ page, isMobile }) => {
  6   |     await page.goto('/');
  7   |     
  8   |     if (isMobile) {
  9   |       // Toggle sidebar on mobile
  10  |       const sidebarTrigger = page.locator('button[data-sidebar="trigger"]');
  11  |       if (await sidebarTrigger.isVisible()) {
  12  |         await sidebarTrigger.click();
  13  |       }
  14  |     }
  15  | 
  16  |     // Verify Sidebar Navigation
  17  |     const identityLink = page.locator('a[href="/identity"]');
> 18  |     await expect(identityLink).toBeVisible();
      |                                ^ Error: expect(locator).toBeVisible() failed
  19  |     await identityLink.click();
  20  |     await expect(page).toHaveURL(/.*\/identity/);
  21  |     
  22  |     // Verify Journey Footer Links (Next)
  23  |     const nextLink = page.locator('a:has-text("Next Step")');
  24  |     await nextLink.click();
  25  |     await expect(page).toHaveURL(/.*\/constitution/);
  26  | 
  27  |     // Verify Keyboard Navigation on buttons
  28  |     await page.keyboard.press('Tab');
  29  |   });
  30  | 
  31  |   test('CRUD Operations & Forms - Identity & Constitution', async ({ page }) => {
  32  |     await page.goto('/identity');
  33  |     
  34  |     // Fill and submit identity
  35  |     await page.fill('textarea[name="mission"]', 'Automated QA Mission');
  36  |     await page.click('button:has-text("Save Mission")');
  37  |     
  38  |     // Verify it saved (page reloaded, value persisted)
  39  |     await expect(page.locator('textarea[name="mission"]')).toHaveValue('Automated QA Mission');
  40  |     
  41  |     // Constitution
  42  |     await page.goto('/constitution');
  43  |     await page.fill('textarea[name="summary"]', 'Automated QA Constitution');
  44  |     await page.click('button:has-text("Save Summary")');
  45  |     await expect(page.locator('textarea[name="summary"]')).toHaveValue('Automated QA Constitution');
  46  |     
  47  |     // Add Principle
  48  |     await page.fill('input[name="title"]', 'QA Principle');
  49  |     await page.fill('input[name="description"]', 'Never ship broken code.');
  50  |     await page.click('button:has-text("Add Principle")');
  51  |     
  52  |     // Verify addition
  53  |     await expect(page.locator('text=QA Principle')).toBeVisible();
  54  | 
  55  |     // Remove Principle
  56  |     await page.locator('button[title="Delete Area"], button[aria-label="Delete Area"], form[action*="removePrinciple"] button').first().click();
  57  |   });
  58  | 
  59  |   test('CRUD Operations & Dropdowns - Goals, Projects, Tasks', async ({ page }) => {
  60  |     // We mock DB on server, so changes persist in memory
  61  |     await page.goto('/life-areas');
  62  |     await page.fill('input[name="title"]', 'QA Life Area');
  63  |     await page.fill('input[name="description"]', 'For testing');
  64  |     await page.click('button:has-text("Add Area")');
  65  |     await expect(page.locator('text=QA Life Area')).toBeVisible();
  66  | 
  67  |     // Dropdowns (native selects)
  68  |     await page.goto('/goals');
  69  |     await page.fill('input[name="title"]', 'QA Goal');
  70  |     await page.selectOption('select[name="lifeAreaId"]', { index: 1 });
  71  |     await page.click('button:has-text("Set Goal")');
  72  |     await expect(page.locator('text=QA Goal')).toBeVisible();
  73  | 
  74  |     // Quick Actions
  75  |     // In Goals, clicking 'Start'
  76  |     const startBtn = page.locator('button:has-text("Start")').first();
  77  |     if (await startBtn.isVisible()) {
  78  |       await startBtn.click();
  79  |     }
  80  |   });
  81  | 
  82  |   test('Client & Server Actions - Habits Check In', async ({ page }) => {
  83  |     await page.goto('/habits');
  84  |     // Ensure we have a habit
  85  |     await page.fill('input[name="title"]', 'QA Habit');
  86  |     await page.selectOption('select[name="lifeAreaId"]', { index: 1 });
  87  |     await page.click('button:has-text("Add Habit")');
  88  |     
  89  |     // Toggle check in
  90  |     const checkInBtn = page.locator('button:has-text("Check In")').first();
  91  |     if (await checkInBtn.isVisible()) {
  92  |       await checkInBtn.click();
  93  |     }
  94  |   });
  95  | 
  96  |   test('Mobile Interactions & Responsiveness', async ({ page, isMobile }) => {
  97  |     await page.goto('/');
  98  |     if (isMobile) {
  99  |       await page.click('button[data-sidebar="trigger"]');
  100 |       await expect(page.locator('text=Command Center')).toBeVisible();
  101 |     }
  102 |   });
  103 | });
  104 | 
```