# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workflows.spec.ts >> Interaction Audit >> CRUD Operations & Forms - Identity & Constitution
- Location: tests/workflows.spec.ts:31:7

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator:  locator('textarea[name="mission"]')
Expected: "Automated QA Mission"
Received: "Automated QA MissionAutomated QA MissionTo build great software that empowers people."
Timeout:  5000ms

Call log:
  - Expect "toHaveValue" with timeout 5000ms
  - waiting for locator('textarea[name="mission"]')
    14 × locator resolved to <textarea id="mission" name="mission" placeholder="What is your ultimate purpose?" class="flex min-h-[100px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring">Automated QA MissionAutomated QA MissionTo build …</textarea>
       - unexpected value "Automated QA MissionAutomated QA MissionTo build great software that empowers people."

```

```yaml
- textbox "What is your ultimate purpose?": Automated QA MissionAutomated QA MissionTo build great software that empowers people.
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | test.describe('Interaction Audit', () => {
  4   | 
  5   |   test('Sidebar and Navigation', async ({ page, isMobile }) => {
  6   |     await page.goto('/');
  7   |     
  8   |     if (isMobile) {
  9   |       // Toggle sidebar on mobile
  10  |       const sidebarTrigger = page.locator('button[data-sidebar="trigger"]');
  11  |       if (await sidebarTrigger.isVisible()) {
  12  |         await sidebarTrigger.click();
  13  |       }
  14  |     }
  15  | 
  16  |     // Verify Sidebar Navigation
  17  |     const identityLink = page.locator('a[href="/identity"]');
  18  |     await expect(identityLink).toBeVisible();
  19  |     await identityLink.click();
  20  |     await expect(page).toHaveURL(/.*\/identity/);
  21  |     
  22  |     // Verify Journey Footer Links (Next)
  23  |     const nextLink = page.locator('a:has-text("Next Step")');
  24  |     await nextLink.click();
  25  |     await expect(page).toHaveURL(/.*\/constitution/);
  26  | 
  27  |     // Verify Keyboard Navigation on buttons
  28  |     await page.keyboard.press('Tab');
  29  |   });
  30  | 
  31  |   test('CRUD Operations & Forms - Identity & Constitution', async ({ page }) => {
  32  |     await page.goto('/identity');
  33  |     
  34  |     // Fill and submit identity
  35  |     await page.fill('textarea[name="mission"]', 'Automated QA Mission');
  36  |     await page.click('button:has-text("Save Mission")');
  37  |     
  38  |     // Verify it saved (page reloaded, value persisted)
> 39  |     await expect(page.locator('textarea[name="mission"]')).toHaveValue('Automated QA Mission');
      |                                                            ^ Error: expect(locator).toHaveValue(expected) failed
  40  |     
  41  |     // Constitution
  42  |     await page.goto('/constitution');
  43  |     await page.fill('textarea[name="summary"]', 'Automated QA Constitution');
  44  |     await page.click('button:has-text("Save Summary")');
  45  |     await expect(page.locator('textarea[name="summary"]')).toHaveValue('Automated QA Constitution');
  46  |     
  47  |     // Add Principle
  48  |     await page.fill('input[name="title"]', 'QA Principle');
  49  |     await page.fill('input[name="description"]', 'Never ship broken code.');
  50  |     await page.click('button:has-text("Add Principle")');
  51  |     
  52  |     // Verify addition
  53  |     await expect(page.locator('text=QA Principle')).toBeVisible();
  54  | 
  55  |     // Remove Principle
  56  |     await page.locator('button[title="Delete Area"], button[aria-label="Delete Area"], form[action*="removePrinciple"] button').first().click();
  57  |   });
  58  | 
  59  |   test('CRUD Operations & Dropdowns - Goals, Projects, Tasks', async ({ page }) => {
  60  |     // We mock DB on server, so changes persist in memory
  61  |     await page.goto('/life-areas');
  62  |     await page.fill('input[name="title"]', 'QA Life Area');
  63  |     await page.fill('input[name="description"]', 'For testing');
  64  |     await page.click('button:has-text("Add Area")');
  65  |     await expect(page.locator('text=QA Life Area')).toBeVisible();
  66  | 
  67  |     // Dropdowns (native selects)
  68  |     await page.goto('/goals');
  69  |     await page.fill('input[name="title"]', 'QA Goal');
  70  |     await page.selectOption('select[name="lifeAreaId"]', { index: 1 });
  71  |     await page.click('button:has-text("Set Goal")');
  72  |     await expect(page.locator('text=QA Goal')).toBeVisible();
  73  | 
  74  |     // Quick Actions
  75  |     // In Goals, clicking 'Start'
  76  |     const startBtn = page.locator('button:has-text("Start")').first();
  77  |     if (await startBtn.isVisible()) {
  78  |       await startBtn.click();
  79  |     }
  80  |   });
  81  | 
  82  |   test('Client & Server Actions - Habits Check In', async ({ page }) => {
  83  |     await page.goto('/habits');
  84  |     // Ensure we have a habit
  85  |     await page.fill('input[name="title"]', 'QA Habit');
  86  |     await page.selectOption('select[name="lifeAreaId"]', { index: 1 });
  87  |     await page.click('button:has-text("Add Habit")');
  88  |     
  89  |     // Toggle check in
  90  |     const checkInBtn = page.locator('button:has-text("Check In")').first();
  91  |     if (await checkInBtn.isVisible()) {
  92  |       await checkInBtn.click();
  93  |     }
  94  |   });
  95  | 
  96  |   test('Mobile Interactions & Responsiveness', async ({ page, isMobile }) => {
  97  |     await page.goto('/');
  98  |     if (isMobile) {
  99  |       await page.click('button[data-sidebar="trigger"]');
  100 |       await expect(page.locator('text=Command Center')).toBeVisible();
  101 |     }
  102 |   });
  103 | });
  104 | 
```