# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workflows.spec.ts >> Interaction Audit >> Mobile Interactions & Responsiveness
- Location: tests/workflows.spec.ts:96:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('text=Command Center')
Expected: visible
Error: strict mode violation: locator('text=Command Center') resolved to 3 elements:
    1) <div data-sidebar="group-label" data-slot="sidebar-group-label" class="flex h-8 shrink-0 items-center rounded-md ring-sidebar-ring outline-hidden transition-[margin,opacity] duration-200 ease-linear group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0 focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0 text-[10px] font-medium tracking-wider text-muted-foreground uppercase px-2 mb-1">Command Center</div> aka getByText('Command Center').first()
    2) <div class="w-full flex-1 font-semibold text-sm text-muted-foreground">Command Center</div> aka locator('header').getByText('Command Center')
    3) <h1 class="text-3xl font-bold tracking-tight">Command Center</h1> aka getByRole('heading', { name: 'Command Center' })

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('text=Command Center')

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main [ref=e3]:
    - generic [ref=e4]:
      - button "Toggle Sidebar" [active] [ref=e5]:
        - img
        - generic [ref=e6]: Toggle Sidebar
      - generic [ref=e7]: Command Center
    - generic [ref=e9]:
      - generic [ref=e10]:
        - generic [ref=e11]:
          - generic [ref=e13]:
            - img
            - text: Wednesday, July 15
          - heading "Command Center" [level=1] [ref=e14]
          - paragraph [ref=e15]: Your personal operating system overview. Stay aligned and execute.
        - generic [ref=e16]:
          - link "Log Journal" [ref=e17] [cursor=pointer]:
            - /url: /journal
            - button "Log Journal" [ref=e18]:
              - img
              - text: Log Journal
          - link "New Task" [ref=e19] [cursor=pointer]:
            - /url: /tasks
            - button "New Task" [ref=e20]:
              - img
              - text: New Task
      - generic [ref=e21]:
        - generic [ref=e22]:
          - generic [ref=e23]:
            - generic [ref=e25]:
              - generic [ref=e26]:
                - img [ref=e27]
                - text: Action Required
              - generic [ref=e29]: Your highest priority tasks and today's focus.
            - generic [ref=e30]:
              - generic [ref=e31]:
                - generic [ref=e32]:
                  - generic [ref=e33]: Complete first 5k run
                  - generic [ref=e34]:
                    - img [ref=e35]
                    - text: 16-Week Training Program
                - button "Done" [ref=e38]
              - generic [ref=e39]:
                - generic [ref=e40]:
                  - generic [ref=e41]: Gather links for recent projects
                  - generic [ref=e42]:
                    - img [ref=e43]
                    - text: Update Portfolio & Resume
                - button "Done" [ref=e46]
          - generic [ref=e47]:
            - generic [ref=e49]:
              - generic [ref=e50]:
                - img [ref=e51]
                - text: Active Projects
              - generic [ref=e53]: Moving the needle forward.
            - generic [ref=e55]:
              - generic [ref=e56]:
                - generic [ref=e57]: 16-Week Training Program
                - generic [ref=e59]: Health & Fitness
              - generic [ref=e61]:
                - generic [ref=e62]: Progress
                - generic [ref=e63]: 15%
        - generic [ref=e66]:
          - generic [ref=e67]:
            - generic [ref=e69]:
              - img [ref=e70]
              - text: Daily Habits
            - generic [ref=e72]:
              - generic [ref=e73]:
                - generic [ref=e74]:
                  - button "Undo habit" [ref=e76]:
                    - img [ref=e77]
                  - generic [ref=e79]: Morning Stretch
                - generic [ref=e80]:
                  - img [ref=e81]
                  - text: "12"
              - generic [ref=e83]:
                - generic [ref=e84]:
                  - button "Complete habit" [ref=e86]:
                    - img [ref=e87]
                  - generic [ref=e89]: Read 10 Pages
                - generic [ref=e90]:
                  - img [ref=e91]
                  - text: "4"
              - generic [ref=e93]:
                - generic [ref=e94]:
                  - button "Complete habit" [ref=e96]:
                    - img [ref=e97]
                  - generic [ref=e99]: QA Habit
                - generic [ref=e100]:
                  - img [ref=e101]
                  - text: "0"
              - generic [ref=e103]:
                - generic [ref=e104]:
                  - button "Complete habit" [ref=e106]:
                    - img [ref=e107]
                  - generic [ref=e109]: QA Habit
                - generic [ref=e110]:
                  - img [ref=e111]
                  - text: "0"
          - generic [ref=e113]:
            - generic [ref=e115]:
              - img [ref=e116]
              - text: OS Insights
            - generic [ref=e128]:
              - generic [ref=e129]:
                - paragraph [ref=e130]: Alignment Check
                - paragraph [ref=e131]: You have 1 active project(s). Keep pushing.
              - generic [ref=e132]:
                - paragraph [ref=e133]: Execution Warning
                - paragraph [ref=e134]: Your task list is manageable (1 pending). Great job staying on top of it.
              - generic [ref=e135]:
                - heading "Trajectory" [level=4] [ref=e136]:
                  - img [ref=e137]
                  - text: Trajectory
                - generic [ref=e143]:
                  - generic [ref=e144]: Run a Marathon
                  - generic [ref=e145]: 35%
          - generic [ref=e148]:
            - generic [ref=e149]:
              - generic [ref=e151]:
                - img [ref=e152]
                - text: Latest Review
              - generic [ref=e157]:
                - generic [ref=e158]:
                  - generic [ref=e159]: WEEKLY
                  - generic [ref=e160]: 8/10
                - paragraph [ref=e161]: Systems over goals. When the habit is tracked, I am 90% more likely to do it.
            - generic [ref=e162]:
              - generic [ref=e164]:
                - img [ref=e165]
                - text: Activity Log
              - generic [ref=e171]:
                - generic [ref=e172]: AWESOME
                - paragraph [ref=e173]: Today was highly productive. I managed to finish the core modules of the project. I feel aligned with my goals.
  - button "Open Next.js Dev Tools" [ref=e179] [cursor=pointer]:
    - img [ref=e180]
  - alert [ref=e183]
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | test.describe('Interaction Audit', () => {
  4   | 
  5   |   test('Sidebar and Navigation', async ({ page, isMobile }) => {
  6   |     await page.goto('/');
  7   |     
  8   |     if (isMobile) {
  9   |       // Toggle sidebar on mobile
  10  |       const sidebarTrigger = page.locator('button[data-sidebar="trigger"]');
  11  |       if (await sidebarTrigger.isVisible()) {
  12  |         await sidebarTrigger.click();
  13  |       }
  14  |     }
  15  | 
  16  |     // Verify Sidebar Navigation
  17  |     const identityLink = page.locator('a[href="/identity"]');
  18  |     await expect(identityLink).toBeVisible();
  19  |     await identityLink.click();
  20  |     await expect(page).toHaveURL(/.*\/identity/);
  21  |     
  22  |     // Verify Journey Footer Links (Next)
  23  |     const nextLink = page.locator('a:has-text("Next Step")');
  24  |     await nextLink.click();
  25  |     await expect(page).toHaveURL(/.*\/constitution/);
  26  | 
  27  |     // Verify Keyboard Navigation on buttons
  28  |     await page.keyboard.press('Tab');
  29  |   });
  30  | 
  31  |   test('CRUD Operations & Forms - Identity & Constitution', async ({ page }) => {
  32  |     await page.goto('/identity');
  33  |     
  34  |     // Fill and submit identity
  35  |     await page.fill('textarea[name="mission"]', 'Automated QA Mission');
  36  |     await page.click('button:has-text("Save Mission")');
  37  |     
  38  |     // Verify it saved (page reloaded, value persisted)
  39  |     await expect(page.locator('textarea[name="mission"]')).toHaveValue('Automated QA Mission');
  40  |     
  41  |     // Constitution
  42  |     await page.goto('/constitution');
  43  |     await page.fill('textarea[name="summary"]', 'Automated QA Constitution');
  44  |     await page.click('button:has-text("Save Summary")');
  45  |     await expect(page.locator('textarea[name="summary"]')).toHaveValue('Automated QA Constitution');
  46  |     
  47  |     // Add Principle
  48  |     await page.fill('input[name="title"]', 'QA Principle');
  49  |     await page.fill('input[name="description"]', 'Never ship broken code.');
  50  |     await page.click('button:has-text("Add Principle")');
  51  |     
  52  |     // Verify addition
  53  |     await expect(page.locator('text=QA Principle')).toBeVisible();
  54  | 
  55  |     // Remove Principle
  56  |     await page.locator('button[title="Delete Area"], button[aria-label="Delete Area"], form[action*="removePrinciple"] button').first().click();
  57  |   });
  58  | 
  59  |   test('CRUD Operations & Dropdowns - Goals, Projects, Tasks', async ({ page }) => {
  60  |     // We mock DB on server, so changes persist in memory
  61  |     await page.goto('/life-areas');
  62  |     await page.fill('input[name="title"]', 'QA Life Area');
  63  |     await page.fill('input[name="description"]', 'For testing');
  64  |     await page.click('button:has-text("Add Area")');
  65  |     await expect(page.locator('text=QA Life Area')).toBeVisible();
  66  | 
  67  |     // Dropdowns (native selects)
  68  |     await page.goto('/goals');
  69  |     await page.fill('input[name="title"]', 'QA Goal');
  70  |     await page.selectOption('select[name="lifeAreaId"]', { index: 1 });
  71  |     await page.click('button:has-text("Set Goal")');
  72  |     await expect(page.locator('text=QA Goal')).toBeVisible();
  73  | 
  74  |     // Quick Actions
  75  |     // In Goals, clicking 'Start'
  76  |     const startBtn = page.locator('button:has-text("Start")').first();
  77  |     if (await startBtn.isVisible()) {
  78  |       await startBtn.click();
  79  |     }
  80  |   });
  81  | 
  82  |   test('Client & Server Actions - Habits Check In', async ({ page }) => {
  83  |     await page.goto('/habits');
  84  |     // Ensure we have a habit
  85  |     await page.fill('input[name="title"]', 'QA Habit');
  86  |     await page.selectOption('select[name="lifeAreaId"]', { index: 1 });
  87  |     await page.click('button:has-text("Add Habit")');
  88  |     
  89  |     // Toggle check in
  90  |     const checkInBtn = page.locator('button:has-text("Check In")').first();
  91  |     if (await checkInBtn.isVisible()) {
  92  |       await checkInBtn.click();
  93  |     }
  94  |   });
  95  | 
  96  |   test('Mobile Interactions & Responsiveness', async ({ page, isMobile }) => {
  97  |     await page.goto('/');
  98  |     if (isMobile) {
  99  |       await page.click('button[data-sidebar="trigger"]');
> 100 |       await expect(page.locator('text=Command Center')).toBeVisible();
      |                                                         ^ Error: expect(locator).toBeVisible() failed
  101 |     }
  102 |   });
  103 | });
  104 | 
```