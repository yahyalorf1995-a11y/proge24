# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workflows.spec.ts >> Interaction Audit >> CRUD Operations & Dropdowns - Goals, Projects, Tasks
- Location: tests/workflows.spec.ts:59:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('text=QA Life Area')
Expected: visible
Error: strict mode violation: locator('text=QA Life Area') resolved to 2 elements:
    1) <div data-slot="card-title" class="font-heading text-lg leading-snug font-semibold tracking-tight text-foreground group-data-[size=sm]/card:text-base mt-4">QA Life Area</div> aka getByText('QA Life Area').first()
    2) <div data-slot="card-title" class="font-heading text-lg leading-snug font-semibold tracking-tight text-foreground group-data-[size=sm]/card:text-base mt-4">QA Life Area</div> aka getByText('QA Life Area').nth(1)

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('text=QA Life Area')

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main [ref=e3]:
    - generic [ref=e4]:
      - button "Toggle Sidebar" [ref=e5]:
        - img
        - generic [ref=e6]: Toggle Sidebar
      - generic [ref=e7]: Command Center
    - generic [ref=e9]:
      - generic [ref=e10]:
        - heading "Life Areas" [level=1] [ref=e11]
        - paragraph [ref=e12]: Categorize your life to maintain balance. Every goal and project will stem from these areas.
      - generic [ref=e13]:
        - generic [ref=e14]:
          - generic [ref=e15]: Add New Area
          - generic [ref=e16]: Create a new dimension of your life to focus on.
        - generic [ref=e18]:
          - textbox "Title (e.g., Finance, Relationships)" [ref=e20]: QA Life Area
          - textbox "Short description..." [ref=e22]: For testing
          - button "Add Area" [active] [ref=e23]
      - generic [ref=e24]:
        - generic [ref=e25]:
          - generic [ref=e26]:
            - generic [ref=e27]:
              - img [ref=e29]
              - button "Delete Area" [ref=e32]:
                - img
            - generic [ref=e33]: Health & Fitness
          - generic [ref=e35]: Physical wellbeing, nutrition, and exercise.
          - generic [ref=e37]:
            - generic [ref=e38]: 3 Goals
            - generic [ref=e39]: 3 Habits
        - generic [ref=e40]:
          - generic [ref=e41]:
            - generic [ref=e42]:
              - img [ref=e44]
              - button "Delete Area" [ref=e48]:
                - img
            - generic [ref=e49]: Career & Business
          - generic [ref=e51]: Professional growth, skills, and networking.
          - generic [ref=e53]:
            - generic [ref=e54]: 1 Goals
            - generic [ref=e55]: 1 Habits
        - generic [ref=e56]:
          - generic [ref=e57]:
            - generic [ref=e58]:
              - img [ref=e60]
              - button "Delete Area" [ref=e65]:
                - img
            - generic [ref=e66]: QA Life Area
          - generic [ref=e68]: For testing
          - generic [ref=e70]:
            - generic [ref=e71]: 0 Goals
            - generic [ref=e72]: 0 Habits
        - generic [ref=e73]:
          - generic [ref=e74]:
            - generic [ref=e75]:
              - img [ref=e77]
              - button "Delete Area" [ref=e82]:
                - img
            - generic [ref=e83]: QA Life Area
          - generic [ref=e85]: For testing
          - generic [ref=e87]:
            - generic [ref=e88]: 0 Goals
            - generic [ref=e89]: 0 Habits
      - generic [ref=e90]:
        - link "Back to Vision" [ref=e91]:
          - /url: /vision
          - button "Back to Vision" [ref=e92]:
            - img
            - text: Back to Vision
        - 'link "Next Step: Set Goals" [ref=e93]':
          - /url: /goals
          - 'button "Next Step: Set Goals" [ref=e94]':
            - text: "Next Step: Set Goals"
            - img
  - button "Open Next.js Dev Tools" [ref=e100] [cursor=pointer]:
    - img [ref=e101]
  - alert [ref=e106]
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | test.describe('Interaction Audit', () => {
  4   | 
  5   |   test('Sidebar and Navigation', async ({ page, isMobile }) => {
  6   |     await page.goto('/');
  7   |     
  8   |     if (isMobile) {
  9   |       // Toggle sidebar on mobile
  10  |       const sidebarTrigger = page.locator('button[data-sidebar="trigger"]');
  11  |       if (await sidebarTrigger.isVisible()) {
  12  |         await sidebarTrigger.click();
  13  |       }
  14  |     }
  15  | 
  16  |     // Verify Sidebar Navigation
  17  |     const identityLink = page.locator('a[href="/identity"]');
  18  |     await expect(identityLink).toBeVisible();
  19  |     await identityLink.click();
  20  |     await expect(page).toHaveURL(/.*\/identity/);
  21  |     
  22  |     // Verify Journey Footer Links (Next)
  23  |     const nextLink = page.locator('a:has-text("Next Step")');
  24  |     await nextLink.click();
  25  |     await expect(page).toHaveURL(/.*\/constitution/);
  26  | 
  27  |     // Verify Keyboard Navigation on buttons
  28  |     await page.keyboard.press('Tab');
  29  |   });
  30  | 
  31  |   test('CRUD Operations & Forms - Identity & Constitution', async ({ page }) => {
  32  |     await page.goto('/identity');
  33  |     
  34  |     // Fill and submit identity
  35  |     await page.fill('textarea[name="mission"]', 'Automated QA Mission');
  36  |     await page.click('button:has-text("Save Mission")');
  37  |     
  38  |     // Verify it saved (page reloaded, value persisted)
  39  |     await expect(page.locator('textarea[name="mission"]')).toHaveValue('Automated QA Mission');
  40  |     
  41  |     // Constitution
  42  |     await page.goto('/constitution');
  43  |     await page.fill('textarea[name="summary"]', 'Automated QA Constitution');
  44  |     await page.click('button:has-text("Save Summary")');
  45  |     await expect(page.locator('textarea[name="summary"]')).toHaveValue('Automated QA Constitution');
  46  |     
  47  |     // Add Principle
  48  |     await page.fill('input[name="title"]', 'QA Principle');
  49  |     await page.fill('input[name="description"]', 'Never ship broken code.');
  50  |     await page.click('button:has-text("Add Principle")');
  51  |     
  52  |     // Verify addition
  53  |     await expect(page.locator('text=QA Principle')).toBeVisible();
  54  | 
  55  |     // Remove Principle
  56  |     await page.locator('button[title="Delete Area"], button[aria-label="Delete Area"], form[action*="removePrinciple"] button').first().click();
  57  |   });
  58  | 
  59  |   test('CRUD Operations & Dropdowns - Goals, Projects, Tasks', async ({ page }) => {
  60  |     // We mock DB on server, so changes persist in memory
  61  |     await page.goto('/life-areas');
  62  |     await page.fill('input[name="title"]', 'QA Life Area');
  63  |     await page.fill('input[name="description"]', 'For testing');
  64  |     await page.click('button:has-text("Add Area")');
> 65  |     await expect(page.locator('text=QA Life Area')).toBeVisible();
      |                                                     ^ Error: expect(locator).toBeVisible() failed
  66  | 
  67  |     // Dropdowns (native selects)
  68  |     await page.goto('/goals');
  69  |     await page.fill('input[name="title"]', 'QA Goal');
  70  |     await page.selectOption('select[name="lifeAreaId"]', { index: 1 });
  71  |     await page.click('button:has-text("Set Goal")');
  72  |     await expect(page.locator('text=QA Goal')).toBeVisible();
  73  | 
  74  |     // Quick Actions
  75  |     // In Goals, clicking 'Start'
  76  |     const startBtn = page.locator('button:has-text("Start")').first();
  77  |     if (await startBtn.isVisible()) {
  78  |       await startBtn.click();
  79  |     }
  80  |   });
  81  | 
  82  |   test('Client & Server Actions - Habits Check In', async ({ page }) => {
  83  |     await page.goto('/habits');
  84  |     // Ensure we have a habit
  85  |     await page.fill('input[name="title"]', 'QA Habit');
  86  |     await page.selectOption('select[name="lifeAreaId"]', { index: 1 });
  87  |     await page.click('button:has-text("Add Habit")');
  88  |     
  89  |     // Toggle check in
  90  |     const checkInBtn = page.locator('button:has-text("Check In")').first();
  91  |     if (await checkInBtn.isVisible()) {
  92  |       await checkInBtn.click();
  93  |     }
  94  |   });
  95  | 
  96  |   test('Mobile Interactions & Responsiveness', async ({ page, isMobile }) => {
  97  |     await page.goto('/');
  98  |     if (isMobile) {
  99  |       await page.click('button[data-sidebar="trigger"]');
  100 |       await expect(page.locator('text=Command Center')).toBeVisible();
  101 |     }
  102 |   });
  103 | });
  104 | 
```